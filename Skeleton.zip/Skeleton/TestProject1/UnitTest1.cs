namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestWeaponLosesDurabilityAfterAttack()
        {
            Axe axe = new Axe(10,10);
            Dummy dummy = new Dummy(10,10);
            axe.Attack(dummy);
         
            Assert.AreEqual(9, axe.DurabilityPoints , "it lost dur");
           
        }
        [Test]
        public void BrokenAxeCantAttack()
        {
            Axe axe = new Axe(2, 2);
            Dummy dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            axe.Attack(dummy);
            var ex = Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
            Assert.That(ex.Message,Is.EqualTo("Axe is broken."));

        }
        [Test]
        public void DummyLosesHealthWhenAttacked()
        {
            Axe axe = new Axe(5, 2);
            Dummy dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.AreEqual(5, dummy.Health, "it lost hp");
        }
        [Test]
        public void TestDeadDummyThrowsExceptionWhenAttacked()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            var ex = Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
            Assert.That(ex.Message, Is.EqualTo("Dummy is dead."));
        }
        [Test]
        public void TestDeadDummyCanGiveXP()
        {
          
            Dummy dummy = new Dummy(10, 10);
            Hero hero = new Hero("John");
            hero.Attack(dummy);
            Assert.AreEqual(10, hero.Experience, "it gained exp");
        }
        [Test]
        public void TestDeadDummyCantGiveXP()
        {

            Dummy dummy = new Dummy(20, 10);
            Hero hero = new Hero("John");
            hero.Attack(dummy);
            Assert.AreEqual(0, hero.Experience, "it gained exp");
        }
    }
}